from django.apps import AppConfig


class CarbonfootprintsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'carbonfootprints'
