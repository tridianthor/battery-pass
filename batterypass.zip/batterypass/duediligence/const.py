media = 'media/duediligence'
diligence_report_path = f'{media}/diligence_report'
third_party_assurances_path = f'{media}/third_party_assurances'