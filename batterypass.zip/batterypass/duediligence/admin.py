from django.contrib import admin
from .models import SupplyChainDueDiligence
# Register your models here.

admin.site.register(SupplyChainDueDiligence)
