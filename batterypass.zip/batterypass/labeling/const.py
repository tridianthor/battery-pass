media = 'media/labeling'
declaration_path = f'{media}/declaration_of_conformity'
result_of_test_path = f'{media}/result_of_test_report'
labeling_symbol_path = f'{media}/labeling_symbol'